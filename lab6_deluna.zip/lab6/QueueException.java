public class QueueException extends RuntimeException
{
  public QueueException(String s) {
    super(s);
  }  // end constructor

  private final static long serialVersionUID = 2006L;
}  // end QueueException
