public class StackException extends java.lang.RuntimeException
{
  public StackException(String s) {
    super(s);
  } // end constructor

  private final static long serialVersionUID = 2006L;
} // end StackException
